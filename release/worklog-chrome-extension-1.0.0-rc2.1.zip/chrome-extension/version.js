export const WORKLOG_VERSION="1.0.0-rc2.1";
